import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideFirebaseApp, getApp, initializeApp } from '@angular/fire/app';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
import { AppComponent } from './app.component';
import { SharedService } from './services/shared.service';

const firebaseConfig = {
  apiKey: "AIzaSyBj1uMbplLYeE-i6FYyGcyEVP5Ha1Hkenw",
  authDomain: "app-tareas-3fdf3.firebaseapp.com",
  projectId: "app-tareas-3fdf3",
  storageBucket: "app-tareas-3fdf3.appspot.com",
  messagingSenderId: "778597643265",
  appId: "1:778597643265:web:27057872463d2d9ee47c00"
};

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    provideFirebaseApp(() => initializeApp( firebaseConfig )),
    provideFirestore(() => getFirestore()),
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
