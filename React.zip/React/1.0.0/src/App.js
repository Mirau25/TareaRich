import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Maria José Mira</h1>

      <div class="row">
  <div class="col-sm-20">
    <div class="Primary">
      <div class="card-body">
        <h5 class="card-title">Majo lo mejorcito</h5>
        <p class="card-text"> 17 años, paisa, morena, cabello crespos, su comida favorita las pastas, le enceanta el color negro.</p>
      </div>
    </div>
  </div>
</div>
  
      </header>
    </div>
  );
}

export default App;
